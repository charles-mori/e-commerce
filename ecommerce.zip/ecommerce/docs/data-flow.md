Data Flow Overview
A product belongs to a brand and a category.

A product can have many product_items (each representing a unique SKU).

Each product_item can have variations (like color and size).

product_image ties images to products.

Additional details like attributes are tied to product_item.